package com.example.pedidosacuadritos.Productos;

public abstract class Niños extends Producto {


    public Niños(String tela, String bolsillo, String bies1, String bies2) {
        super(tela, bolsillo, bies1, bies2);
        cantCierres = 0;

    }
}
