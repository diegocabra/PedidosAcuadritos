package com.example.pedidosacuadritos.Productos;

public class Adulto extends Producto {

    public Adulto(String tela, String bolsillo, String bies1, String bies2) {
        super(tela, bolsillo, bies1, bies2);
        precio = 950;
        cantTela = 0.95;
        cantCierres = 0;
    }
}
